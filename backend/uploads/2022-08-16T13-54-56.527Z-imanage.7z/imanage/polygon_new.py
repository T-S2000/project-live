# Idea is to find the equation of two lines adjacent to each other to find the vertex of the new polygon assiciated with them. To do this, slope,y-intercept of the new lines m1,m2 and c1,c2 
# are used to find the new intercepts, c1_new,c2,new of the new lines, and the intersecting point of these two lines which are parallel to the initial lines is used
#  to find the corresponding vertex of the new polygon. This process is repeated 'n' times, where 'n' is the number of vertices
import math
from inside_polygon import is_inside_polygon


def slope (a,b):
    if(a[0] == b[0]):
        return math.inf
    else:
        return ((b[1]-a[1])/(b[0]-a[0]))

#  returns array of y intercepts ( two nos ) of two new lines at the given distance given slope, distance and y itercept of parallel line
def find_intercept(m,c,d):
    temp = d*math.sqrt(1+m*m)
    to_return  = []
    to_return.append(c-temp)
    to_return.append(c+temp)
    return to_return

#  finds intersection point bw two lines
def intersection(m1,b1,m2,b2):
    xi = (b1-b2) / (m2-m1)
    yi = m1 * xi + b1

    return (xi,yi)

# finds the yintercept of a line given slope and a point on the line [ y = mx+ c]
def get_c(a,m):
    return (a[1] - m*a[0])

# find 4 points for each vertex intersection.
def find_candidates(m1,new_c1,m2,new_c2,vertices):
    to_return = []
    for i in new_c1:
        for j in new_c2:
            res = intersection(m1,i,m2,j)
            if(is_inside_polygon(vertices,res)):
                to_return.append(res)
    return to_return

# function if one line is parallel to y-axis
# find the vertices for the case when one of the slopes is undefined,acc to the formulae, y = c1+ mc2 , x = c2
def find_candidates_parallel(m,new_c1,new_c2,vertices):
    to_return = []
    for i in new_c1 :
        for j in new_c2:
            res = (j,(i + (m*j)))
            if(is_inside_polygon(vertices,res)):
                to_return.append(res)
    return to_return

# d = int(input("Enter the distace"))

# n = int(input("Enter the number of vertices"))
# vertices = []
# for i in range(n):
#     print("vertex no", i+1)
#     a = int(input("X axis:" ))
#     b = int(input("Y axis:"))
#     vertices.append((a,b))

#  test driver --------------------------------------------------------------------------------------------------
d = 5
n = 9
vertices = [(-20,50),(60,50),(80,30),(80,-10),(50,-10),(50,10),(20,10),(20,-10),(0,-10)]
# __________________________________________________________________________________________________________________

print("Original Vertices")
print(vertices)
result = []

for i in range(n):
    # iterator = (n-1 + i)%n
    a = vertices [i]
    b = vertices[(i + 1)%n]
    c = vertices[(i + 2)%n]


    
    m1 = slope(a,b)
    m2 = slope(b,c)

    # test for parallel to y axis ___________________________________________________________________________________________________

    if (m1 == math.inf):

        c_intercept =  b[0] 
        m = m2 
        new_c1 = [c_intercept-d,c_intercept+d]
        c2 = get_c(b,m2)
        new_c2 = find_intercept(m2,c2,d)
        final_point = find_candidates_parallel(m,new_c2,new_c1,vertices)
    
    elif(m2 == math.inf):
        c_intercept = b[0]
        m = m1
        c1 = get_c(b,m1)
        new_c1 = find_intercept(m1,c1,d)
        new_c2 = [c_intercept-d,c_intercept+d]
        final_point = find_candidates_parallel(m,new_c1,new_c2,vertices)

# if not parallel to y axis ________________________________________________________________________________________________
    else:

        c1 = get_c(b,m1)
        c2 = get_c(b,m2)

        new_c1 = find_intercept(m1,c1,d)
        new_c2 = find_intercept(m2,c2,d)
        final_point = find_candidates(m1,new_c1,m2,new_c2,vertices)

    for i in final_point:
        result.append(i)
print("vertices of new polygon")
print(result)


